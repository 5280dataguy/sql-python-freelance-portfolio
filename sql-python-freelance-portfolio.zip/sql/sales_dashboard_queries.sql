-- sales_dashboard_queries.sql
-- Returns weekly sales performance by product category

SELECT
    DATE_TRUNC('week', order_date) AS week_start,
    category,
    COUNT(order_id) AS total_orders,
    SUM(total_amount) AS revenue,
    AVG(total_amount) AS avg_order_value
FROM
    orders
GROUP BY 1, 2
ORDER BY 1 DESC, 2;
