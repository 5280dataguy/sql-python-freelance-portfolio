-- data_cleaning_example.sql
-- Cleans customer data and flags invalid entries

SELECT
    *,
    CASE
        WHEN email IS NULL OR NOT email LIKE '%@%.%' THEN 'Missing or invalid email'
        WHEN LENGTH(phone) < 10 THEN 'Invalid phone number'
        ELSE NULL
    END AS data_issue
FROM
    customers;
