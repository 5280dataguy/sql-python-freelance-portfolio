# api_data_fetcher.py
import requests
import pandas as pd

# Example: Fetching public data from a placeholder API
url = "https://jsonplaceholder.typicode.com/posts"
response = requests.get(url)

if response.status_code == 200:
    posts = response.json()
    df = pd.DataFrame(posts)
    df.to_csv('api_posts.csv', index=False)
    print("Data saved to api_posts.csv")
else:
    print("Failed to retrieve data. Status code:", response.status_code)
