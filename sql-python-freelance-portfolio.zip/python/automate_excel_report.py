# automate_excel_report.py
import pandas as pd

# Load sales data
df = pd.read_csv('../sample_data/sales_data.csv')

# Create a summary report
summary = df.groupby('region').agg({
    'order_id': 'count',
    'total_amount': ['sum', 'mean']
}).reset_index()

# Write to Excel
summary.columns = ['Region', 'Total Orders', 'Total Revenue', 'Average Order Value']
summary.to_excel('weekly_sales_report.xlsx', index=False)

print("Report created: weekly_sales_report.xlsx")
