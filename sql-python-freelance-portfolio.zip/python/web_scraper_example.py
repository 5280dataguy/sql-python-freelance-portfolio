# web_scraper_example.py
import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://example.com/products"
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')

# Fake logic for demo purposes
data = []
for i in range(1, 6):
    data.append({
        'Product': f"Sample Product {i}",
        'Price': f"${10 + i * 5}"
    })

df = pd.DataFrame(data)
df.to_csv('scraped_products.csv', index=False)
print("Scraped data saved to scraped_products.csv")
